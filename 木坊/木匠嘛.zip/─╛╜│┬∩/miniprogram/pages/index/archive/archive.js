// miniprogram/pages/index/archive/archive.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: {},
  },

  getData: function () {
    // var db = wx.cloud.database();
    var that = this;

    wx.cloud.callFunction({
      // 云函数名称
      name: 'db',
      // 传给云函数的参数
      data: {
        type: 'get'
      },
      success: function (res) {
        var result = res.result || {};
        that.dealData(result.data, function (data) {
          that.setData({
            list: data
          });
          getApp().globalData.archive = that.data.list;
        });
      },
      fail: function () {
      }
    })
  },
  showdetail: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../detail/detail?imgData=' + that.data.list[parseInt(e.currentTarget.dataset.index)].img + '&comData=' + that.data.list[parseInt(e.currentTarget.dataset.index)].comment + '&nameData=' + that.data.list[parseInt(e.currentTarget.dataset.index)].name
    })
  },
  dealData: function (list, callback) {
    var fileList = [];

    list.forEach(function (item) {
      var date = new Date(item.time);

      item.timeInfo = {
        year: date.getFullYear(),
        month: date.getMonth() + 1,
        date: date.getDate(),
        hours: date.getHours(),
        miniutes: date.getMinutes()
      };

      fileList.push(item.img);
    });

    wx.cloud.getTempFileURL({
      fileList: fileList,
      success: function (res) {
        var fileList = res.fileList;

        list.forEach(function (item, index) {
          item.img = fileList[index].tempFileURL;
        });

        callback(list);
      },
      fail: function (err) {
        wx.showToast({
          title: err
        });
      }
    })
  },
  onLoad: function (options) {
    if (getApp().globalData.archive){
      console.log('1')
      this.setData({
        list: getApp().globalData.archive
      })
   
    }else{
      wx.showToast({
        title: '加载中',
        icon: 'loading',
      })
      this.getData();
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})