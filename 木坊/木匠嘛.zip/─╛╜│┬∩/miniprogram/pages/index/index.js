//index.js
var app = getApp()

var pages = getCurrentPages();
var currPage = pages[pages.length - 1];   //当前页面
var prevPage = pages[pages.length - 2];

Page({
  data: {
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    useropenid:'点击登陆>',

    avatarUrl:'./user-unlogin.png',
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',

    show_hide_game:'block',
    show_hide_book:'none',
    show_hide_continer: 'none',
   
    list: {},

    navicon_old: ['/images/icon/learn.png', '/images/icon/book.png','/images/icon/mine.png'],
    navicon_new: [ '/images/icon/color/learn1.png', '/images/icon/color/book1.png', '/images/icon/color/mine1.png'],
    nav_icon2: "/images/icon/color/learn1.png",
    nav_icon3: "/images/icon/book.png",
    nav_icon4: "/images/icon/mine.png",
  },

  show_continer:function(){
    var that =this;
    wx.setNavigationBarTitle({
      title: '我的',
    })
     this.setData({
       show_hide_continer:'block',
       show_hide_game: 'none',
       show_hide_book: 'none',

       nav_icon2: that.data.navicon_old[0],
       nav_icon3: that.data.navicon_old[1],
       nav_icon4: that.data.navicon_new[2],
     })
  },
  show_game: function () {
    var that = this;
    wx.setNavigationBarTitle({
      title: '线上教学',
    })
    this.setData({
      show_hide_continer: 'none',
      show_hide_game: 'block',
      show_hide_book: 'none',

      nav_icon2: that.data.navicon_new[0],
      nav_icon3: that.data.navicon_old[1],
      nav_icon4: that.data.navicon_old[2],
    })
  },
  show_book: function () {
    var that = this;
    wx.setNavigationBarTitle({
      title: '线下实践',
    })
    this.setData({
      show_hide_continer: 'none',
      show_hide_game: 'none',
      show_hide_book: 'block',

      nav_icon2: that.data.navicon_old[0],
      nav_icon3: that.data.navicon_new[1],
      nav_icon4: that.data.navicon_old[2],
    })
  },
  begin_one:function(){
        wx.navigateTo({
          url: 'level/level_one/level_one',
        })
  },
 
  aboutbook:function(){
    wx.navigateTo({
      url: 'book/aboutbook/aboutbook',
    })
  },
  booking:function(e){
    if(app.globalData.openId){
      wx.navigateTo({
        url: 'book/booking/booking',
      })
    }else{
      this.getUserInfo(e)
    }

  },
  bookrecord:function(e){
    if(app.globalData.openId){
      wx.navigateTo({
        url: 'book/orderlist/orderlist',
      })
    }else{
      this.getUserInfo(e)
    }

  },
//   passinfo:function(){
//   app.globalData.list = this.data.list;
//   console.log(app.globalData.list)
//   console.log(this.data.list)
// },

  // 获取用户openid
  getOpenid() {
    let that = this;
    wx.cloud.callFunction({
      name: 'getOpenid',
      complete: res => {
        
        var openid = res.result.openId;
        app.globalData.openId = openid;
        that.setData({
         
        })
        console.log(app.globalData.openId)
      }
    })
  },
  onLoad: function() {
  
    this.getOpenid();
    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
    }


  },
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //  获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              console.log(res)
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                userInfo: res.userInfo,
                useropenid: res.userInfo.nickName
              })
              app.globalData.userinfo = res.userInfo
            }
          })
        }
      }
    })
  },
  // onGetUserInfo: function(e) {
  //   if (!this.logged && e.detail.userInfo) {
  //     this.setData({
  //       logged: true,
  //       avatarUrl: e.detail.userInfo.avatarUrl,
  //       userInfo: e.detail.userInfo
  //     })
  //   }
  // },

  



  getUserInfo: function (e) {
    let that =this;
    if (e.detail.userInfo) {
      wx.login({
        success(res) {
          if (res.code) {
           that.setData({
              // openid: getApp().globalData.openid,
          useropenid: e.detail.userInfo.nickName,
           avatarUrl: e.detail.userInfo.avatarUrl
            // province: e.detail.userInfo.province,
            //     city: e.detail.userInfo.city
        })
          } else {
            console.log('登录失败！' + res.errMsg)
          }
        }
      })
      wx.switchTab({
        url: '/pages/index/index'
      })
    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '警告',
        content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
        showCancel: false,
        confirmText: '返回授权',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击了“返回授权”')
          }
        }
      })
    }
  },
  //获取用户信息接口
  queryUsreInfo: function () {
    wx.request({
      url: getApp().globalData.urlPath + 'user/userInfo',
      data: {
        openid: app.globalData.openid
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        app.globalData.userInfo = res.data;
      }
    })
      },
      showtoast:function(){
           wx.showToast({
             title:"努力制作教程中...",
             image:"./smile.png"
           })
      }

})
