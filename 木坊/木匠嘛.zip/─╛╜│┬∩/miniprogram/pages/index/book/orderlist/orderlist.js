var app = getApp()
Page({
  data: {
    buttonDisabled: false,
    modalHidden: true,
    show: false,
    orderlist:{},
    opneid:"",
    _id:"",
    norecord: "none"
  },

  showModal: function (e) {
    this.setData({
      modalHidden: !this.data.modalHidden,
      _id: e.currentTarget.dataset._id
    })
  },
  modalBindaconfirm: function () {
    let _id = this.data._id;
    this.onCounterDec(_id)
    this.setData({
      modalHidden: !this.data.modalHidden,
      show: !this.data.show,
      buttonDisabled: !this.data.buttonDisabled
    })

    this.onLoad()
  },
  modalBindcancel: function (e) {
    this.setData({
      modalHidden: !this.data.modalHidden,
     
    })
  },


  onQuery: function () {
    var that = this;
    const db = wx.cloud.database()
    // 查询当前用户所有的 userinfo
    db.collection('order').where({
      _openid: that.data.openid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
        if (res.data.length != 0) {

          this.setData({
            //_id: res.data[0]._id
            orderlist:res.data.reverse()
          })
        }else{
         
          this.setData({
            norecord: 'block'
          })
        }
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
  },

  onCounterDec: function (_id) {
    const db = wx.cloud.database()
   console.log(_id)
    db.collection('order').doc(_id).update({
      data: {
        status:'已取消'
      },
      success: res => {
        this.setdata({
          _id:''
        })
        wx.showToast({
          title: '取消预约状态成功',
        })
      },
      fail: err => {
        icon: 'none',
        console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  },
  onLoad: function (options) {
       this.setData({
         openid: app.globalData.openId
       })
      this.onQuery()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})