//index.js
//获取应用实例
const app = getApp()
var dateTimePicker = require('./dateTimePicker.js');

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    toastHidden: true,
    notice_str: '',
    // date: '2019-05-01',
    // time: '12:00',
    dateTimeArray: null,
    dateTime: null,
    dateTimeArray1: null,
    dateTime1: null,
    startYear: 2019,
    endYear: 2019,
    data:'',
    startData:'',
    endData:''
  },
  bindDateChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  onLoad: function () {
    // 获取完整的年月日 时分秒，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    var obj1 = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);

    // 精确到分的处理，将数组的秒去掉
    var lastArray = obj1.dateTimeArray.pop();
    var lastTime = obj1.dateTime.pop();
   
    let year = obj1.dateTimeArray[0][obj1.dateTime[0]];
    let month = obj1.dateTimeArray[1][obj1.dateTime[1]];
    let day = obj1.dateTimeArray[2][obj1.dateTime[2]];
  console.log(year+"-"+month+"-"+day)
  
  if (month == '02' ){
      if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)){
            if(parseInt(day) >= 24){
              day ='0'+(7- (29-parseInt(day)));
             if(parseInt(month)>=9){
               month = '' + (parseInt(month) + 1)
             }else{
               month = '0' + (parseInt(month) + 1)
             }
              this.setData({
                endData:year+'-'+month+'-'+'-'+day
              })
            }else{
              this.setData({
                endData: year + '-' + month + '-' + day 
        })
            }
      }else{
        if (parseInt(day) >= 23) {
          if (parseInt(month) >= 9) {
            month = '' + (parseInt(month) + 1)
          } else {
            month = '0' + (parseInt(month) + 1)
          }
          day = '0' + (7 - (28 - parseInt(day)));
          this.setData({
            endData: year + '-' + month + '-' + '-' + '1'
          })
        } else {
          this.setData({
            endData: year + '-' + month + '-' + day
          })
      }  } 
    }else{
    if (month == '01' || '03' || '05' || '07' || '08' || '10' || '12'){
        if(parseInt(day) >= 26){
          day = '0' + (7 - (31 - parseInt(day)));
          if (parseInt(month) >= 9) {
            month = '' + (parseInt(month) + 1)
          } else {
            month = '0' + (parseInt(month) + 1)
          }
          this.setData({
            endData: year + '-' + month + '-' + day
          })   
        }else{
          this.setData({
            endData: year + '-' + month + '-' + day
          }) 
        }
    }else{
      if (parseInt(day) >= 25) {
        if (parseInt(month) >= 9) {
          month = '' + (parseInt(month) + 1)
        } else {
          month = '0' + (parseInt(month) + 1)
        }
        day = '0' + (7 - (30 - parseInt(day)))
        this.setData({
          endData: year + '-' + month + '-' + day
        })
      } else {
        this.setData({
          endData: year + '-' + month + '-' + day
        })
      }
    }
    }
   

    this.setData({
      startData: obj1.dateTimeArray[0][obj1.dateTime[0]] + "-" + obj1.dateTimeArray[1][obj1.dateTime[1]]+"-"+obj1.dateTimeArray[2][obj1.dateTime[2]],
  
   
    });
    console.log(obj1)
  },
  bindDateChange: function (e) {
    var that = this;
    that.setData({
      date: e.detail.value
    })
    console.log(that.data.date);
  },

  onAdd: function (formData) {
    var that = this;
    console.log(formData)
    const db = wx.cloud.database()
    db.collection('order').add({
      data: {
        name: formData.username,
        gender:formData.gender,
        phone:formData.phone,
        enterdate:formData.enterdate,
        count:formData.count,
        status:'待体验'
      },
      success: res => {
        wx.showToast({
          title: '新增记录成功',
        })
        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '新增记录失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
      }
    })
  },
  //提交信息
  formSubmit: function (e) {
    //表单校验
    if (!this.checkForm(e)) {
      return false;
    }
    var that = this;
    var formData = e.detail.value;
    //提交表单
     that.onAdd(formData);
    
        //清空表单
        that.setData({
          username: '',
          phone: '',
          count: ''
        })
      
  
  },
  to_map: function () {
   
    wx.navigateTo({
      url: 'map/map'
    })
  },
  // formBindsubmit: function (e) {
  //   if (e.detail.value.username.length == 0 || e.detail.value.phone.length == 0) {
  //     wx.showToast({
  //       title: '姓名或电话不为空',
  //       icon: 'loading',
  //       duration: 1000,
  //       mask: true
  //     })
  //   } 
  // },
  checkForm: function (e) {
    if (e.detail.value.username.length == 0) {
      wx.showToast({
        title: '姓名不能为空',
        icon: 'loading',
        duration: 1000,
        mask: true
      })
      return false;
    }
    var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
    if (!myreg.test(e.detail.value.phone)) {
      wx.showToast({
        title: '手机号格式有误',
        icon: 'loading',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (e.detail.value.enterdate.length == 0) {
      wx.showToast({
        title: "请选择时间",
        icon: 'loading',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (e.detail.value.count.length == 0) {
      wx.showToast({
        title: "请填写人数",
        icon: 'loading',
        duration: 1000,
        mask: true
      })
      return false;
    }
    return true;
  },


})
