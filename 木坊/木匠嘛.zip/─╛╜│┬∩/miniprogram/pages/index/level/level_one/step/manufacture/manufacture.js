// miniprogram/pages/index/level/level_one/step/manufacture/manufacture.js
Page({



  play:function(e){
      wx.navigateTo({
        url: './videos/videos?index='+e.currentTarget.dataset.index,
      })
  },
  onLoad: function (options) {

  },
toast:function(){
wx.showToast({
  title: '只有三个喔!',
  image:'../../image_text/smile.png'
})
},

  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})