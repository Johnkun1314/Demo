var app = getApp()
Page({


  data: {
    showAdd: true,
    form: {
      openid:'',
      img: '',
      comment: '',
      time: ''
    },
    openid:'',
    userinfo:{},
    dbname:''
  },

 his_comment:function(){
   app.globalData.db='';
   wx.navigateTo({
     url: './his_comment/his_comment?db='+this.data.dbname,
   })
 },
  oninput: function (e) {
    this.setData({
      'form.comment': e.detail.value
    })
  },
  addpic: function (e) {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        that.setData({
          showAdd: false,
          'form.img': res.tempFilePaths[0],
        })
      }
    })
  },

  save: function (e) {
    wx.showToast({
      title: '发表中...',
      icon:'loading'
    })
    console.log('begin upload pic')
    var form = this.data.form;
    var that = this;
    var cloudpath = "pic" + this.guid();
    wx.cloud.uploadFile({
      cloudPath: cloudpath,
      filePath: form.img, // 文件路径
      success: res => {
        // get resource ID
      
        console.log(res.fileID);
        that.addToDB(res.fileID)
      },
      fail: err => {
        console.log('fail')
      }
    })
  },

  addToDB: function (fileID) {
    console.log("begain addtoDB");
    var that=this;
    var dbname =  that.data.dbname
    var form = this.data.form;
    wx.cloud.callFunction({
      // 云函数名称
      name:'learn_comment',
      // 传给云函数的参数
      data: {

        dbname:dbname,
        type: 'add',
        img: fileID,
        comment: form.comment,
        openid:that.data.openid,
        userinfo:that.data.userinfo
      },
      success(res) {
        console.log('upload success!'),
          wx.showToast({
            title: '发表成功',
            icon:'success',
          
          })
        wx.navigateBack({
          delta: 1
        })
      },
      fail() {
        console.log('upload fail!')
      }
    })
  },

  S4: function () {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
  },
  guid: function () {
    return (this.S4() + this.S4() + "-" + this.S4() + "-" + this.S4() + "-" + this.S4() + "-" + this.S4() + this.S4() + this.S4());
  },

  onLoad:function(options){
    if (app.globalData.openId) {
      this.setData({
        dbname:options.dbname,
        openid: app.globalData.openId,
        userinfo: app.globalData.userinfo
      })
    }
    console.log(this.data.dbname)

  }
})
