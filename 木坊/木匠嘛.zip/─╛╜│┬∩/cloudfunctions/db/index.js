// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init();
var db = cloud.database();
// 云函数入口函数
exports.main = async (event, context) => {
  console.log(event);
  if (event.type == 'add') {
    return addData(event, context);
  } else {
    return getData(event, context);
  }
}

function getData(e, context) {
  return db.collection('carpenter').get();
}

function addData(e, context) {
  return new Promise(function (resolve, reject) {
    db.collection('carpenter').add({
      data: {
        img: e.img,
        comment: e.comment,
        time: Date.now(),
        name: e.name
      }
    })
  })
}