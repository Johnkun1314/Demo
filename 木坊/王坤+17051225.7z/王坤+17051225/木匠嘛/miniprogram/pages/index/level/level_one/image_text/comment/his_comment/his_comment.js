function fixZero(num) {
  return num < 10 ? '0' + num : num;
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
      dbname:'',
      openid:'',
      record:{},
      del_id:'',
      norecord:"none"
  },

  dealData: function (list, callback) {
    var fileList = [];

    list.forEach(function (item) {
      var date = new Date(item.time);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        miniutes: fixZero(date.getMinutes())
      };

      fileList.push(item.img);
    });

    wx.cloud.getTempFileURL({
      fileList: fileList,
      success: function (res) {
        var fileList = res.fileList;

        list.forEach(function (item, index) {
          item.img = fileList[index].tempFileURL;
        });

        callback(list);
      },
      fail: function (err) {
        wx.showToast({
          title: err
        });
      }
    })
  },

  onQuery: function () {
    let that = this;
    const db = wx.cloud.database()
    // 查询当前用户所有的 userinfo
    db.collection(this.data.dbname).where({
      _openid: this.data.openid
    }).get({
      success: res => {

        that.dealData(res.data, function (data) {
          that.setData({
            record: data.reverse()
          });
        });
        this.setData({
          // record: JSON.stringify(res.data, null, 2)
          record:res.data
        })
        console.log('[数据库] [查询记录] 成功: ', res)
        console.log(this.data.record);

        if (this.data.record.length == 0) {
          this.setData({
            norecord:'block'
          })
        }

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
  },
  onRemove: function () {
    if (this.data.del_id) {
      const db = wx.cloud.database()
      db.collection(this.data.dbname).doc(this.data.del_id).remove({
        success: res => {
          wx.showToast({
            icon:'success',
            title: '删除成功',
          })
          this.setData({
           del_id: ''
          })
          this.onLoad();
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '删除失败',
          })
          console.error('[数据库] [删除记录] 失败：', err)
        }
      })
    } else {
      wx.showToast({
        title: '无记录可删，请见创建一个记录',
      })
    }
  },
  del_comment:function(e){
    this.setData({
      del_id:e.currentTarget.dataset.id
    })
       this.onRemove();
  },
  onLoad: function (options) {
            this.setData({
              openid: getApp().globalData.openId,
            })

            if(getApp().globalData.db){
              this.setData({
                dbname: getApp().globalData.db
              })
            }else{
              this.setData({
                dbname: options.db
              })
              getApp().globalData.db = options.db 
            }
    this.onQuery();
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})