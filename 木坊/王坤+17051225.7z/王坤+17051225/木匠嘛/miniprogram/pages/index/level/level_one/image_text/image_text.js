var app = getApp()

function fixZero(num) {
  return num < 10 ? '0' + num : num;
}
Page({

  data: {
     introduce:{},
     introduce_image:{},
     record:{},
     dbname:'',
     index:''
  },
  getData_introduce_image: function (index) {
    // var db = wx.cloud.database();
    var that = this;
    console.log('image1')
    wx.cloud.callFunction({
      // 云函数名称
      name: 'gettext_image',
      // 传给云函数的参数
      data: {
        type: 'get'
      },
      success: function (res) {
        var result = res.result.data || {};
        console.log('image2')
        switch (index) {
          case '2': {
                    that.setData({
          introduce_image: result.slice(0,1),
                      dbname: 'comment_chair_2'
        });
            console.log('image3')
            that.getData();
            wx.setNavigationBarTitle({
              title: '设计图',
            }); break
          }
          case '3': {
                    that.setData({
                      dbname: 'comment_chair_3',
          introduce_image: result.slice(1,3)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '取材与配料',
            }); break
          }
          case '4': {
                    that.setData({
                      dbname: 'comment_chair_4',
          introduce_image: result.slice(3,4)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '制作工具',
            }); break
          }
          case '5': {
                    that.setData({
                      dbname: 'comment_chair_5',
          introduce_image: result.slice(4,14)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '净料与划线',
            }); break
          }
          case '6': {
                    that.setData({
                      dbname: 'comment_chair_6',
          introduce_image: result.slice(14,18)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '打眼与开榫',
            }); break
          }
          case '7': {
                    that.setData({
                      dbname: 'comment_chair_7',
          introduce_image: result.slice(18,22)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '截榫与塑形',
            }); break
          }
          case '8': {
                    that.setData({
                      dbname: 'comment_chair_8',
          introduce_image: result.slice(22,24)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '组装与校准',
            }); break
          }
          case '9': {
                    that.setData({
                      dbname: 'comment_chair_9',
          introduce_image: result.slice(24,27)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '净面与打磨',
            }); break
          }
          case '10': {
                    that.setData({
                      dbname: 'comment_chair_10',
          introduce_image: result.slice(27,28)
        });
            that.getData();
            wx.setNavigationBarTitle({
              title: '作品展示',
            }); break
          }
        }
      },
      fail: function () {
      }
    })
  },
  getData_introduce: function (index) {
    // var db = wx.cloud.database();
    var that = this;

    wx.cloud.callFunction({
      // 云函数名称
      name: 'gettext_image',
      // 传给云函数的参数
      data: {
        type: 'introduce'
      },
      success: function (res) {
        var result = res.result.data || {};
      
          that.setData({
            introduce: result,
            dbname: 'comment_chair_1'
        });
   
      },
      fail: function () {
      }
    })
  },


  dealData: function (list, callback) {
    var fileList = [];

    list.forEach(function (item) {
      var date = new Date(item.time);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        miniutes: fixZero(date.getMinutes())
      };

      fileList.push(item.img);
    });

    wx.cloud.getTempFileURL({
      fileList: fileList,
      success: function (res) {
        var fileList = res.fileList;

        list.forEach(function (item, index) {
          item.img = fileList[index].tempFileURL;
        });

        callback(list);
      },
      fail: function (err) {
        wx.showToast({
          title: err
        });
      }
    })
  },

  getData: function () {
    // var db = wx.cloud.database();
    var that = this;
    console.log(this.data.dbname)
    wx.cloud.callFunction({
      // 云函数名称
      name: 'learn_comment',
      // 传给云函数的参数
      data: {
        dbname:that.data.dbname,
        type: 'get'
      },
      success: function (res) {
        console.log('获取成功');
        console.log(res);
        var result = res.result || {};
        
        that.dealData(result.data, function (data) {
          that.setData({
            record: data.reverse()
          });
        });
      },
      fail: function () {
      }
    })
  },
comment:function(e){
  let that =this;

  if(app.globalData.openId){
    wx.navigateTo({
      url: './comment/comment?dbname=' + that.data.dbname,
    })
  }else{
    wx.showToast({
      title: '请先登录!',
      image: './smile.png',
      duration: 500,
    })
    this.getUserInfo(e)
  }
},

imgYu:function(event){
  var src = event.currentTarget.dataset.src;//获取data-src
  var imgList =[];
  imgList.push(src);
  //图片预览
  wx.previewImage({
    current: src, // 当前显示图片的http链接
    urls: imgList // 需要预览的图片http链接列表
  })
},
  onReady: function () {

  },

  onLoad: function (options) {
    wx.showToast({
      title: '加载中...',
      icon: 'loading'
    })
    let that = this;
   //  options.index= '5';  //测试
    let opindex = options.index;
    if (app.globalData.index) {
      console.log('1')
      this.setData({
        index: app.globalData.index
      })
    } else {
      console.log('2')
      this.setData({
        index: opindex
      })
      app.globalData.index = this.data.index;
    }
  },
  onShow: function () {

   let that =this;
   let index = this.data.index;
    console.log(index)
    if (index == '1') {
      this.getData_introduce();
      this.setData({
        dbname: 'comment_chair_1'
      })
      that.getData();
      wx.setNavigationBarTitle({
        title: '制作与序言',
      });
    } else {
      console.log('image')
      this.getData_introduce_image(index);
    }
  },
  getUserInfo: function (e) {
    let that = this;
    if (e.detail.userInfo) {
      wx.login({
        success(res) {
          if (res.code) {
            that.setData({
              // openid: getApp().globalData.openid,
              useropenid: e.detail.userInfo.nickName,
              avatarUrl: e.detail.userInfo.avatarUrl
              // province: e.detail.userInfo.province,
              //     city: e.detail.userInfo.city
            })
          } else {
            console.log('登录失败！' + res.errMsg)
          }
        }
      })
      wx.navigateTo({
        url: './comment/comment?dbname=' + that.data.dbname,
      })
    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '警告',
        content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
        showCancel: false,
        confirmText: '返回授权',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击了“返回授权”')
          }
        }
      })
    }
  },
  onHide: function () {

  },


  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.startPullDownRefresh({
      success:function(){
          wx.showToast({
            title: '刷新成功',
            duration:1000
          })
        
      }
    })
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})