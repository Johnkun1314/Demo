// miniprogram/pages/index/level/level_one/step/manufacture/videos/videos.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
         videosrc:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      console.log(options.index);
      var index = options.index;
      switch(index){
        case '1': this.setData({ videosrc:'cloud://johnke-993a75.6a6f-johnke-993a75/carpenter/插件.mp4'});break;
        case '2': this.setData({ videosrc:'cloud://johnke-993a75.6a6f-johnke-993a75/carpenter/木板划线.mp4'});break;
        case '3': this.setData({ videosrc:'cloud://johnke-993a75.6a6f-johnke-993a75/carpenter/板凳腿.mp4'});break;
      }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})