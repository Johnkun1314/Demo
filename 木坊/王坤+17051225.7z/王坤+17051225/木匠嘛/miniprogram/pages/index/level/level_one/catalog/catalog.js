
Page({


  data: {
    showAdd: true,
    form: {
      img: '',
      comment: '',
      time: ''
    }
  },

  oninput: function (e) {
    this.setData({
      'form.comment': e.detail.value
    })
  },
  addpic: function (e) {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        that.setData({
          showAdd: false,
          'form.img': res.tempFilePaths[0],
        })
      }
    })
  },

  save: function (e) {
    console.log('begin upload pic')
    var form = this.data.form;
    var that = this;
    var cloudpath = "pic" + this.guid();
    wx.cloud.uploadFile({
      cloudPath: cloudpath,
      filePath: form.img, // 文件路径
      success: res => {
        // get resource ID
        console.log(res.fileID);
        that.addToDB(res.fileID)
      },
      fail: err => {
        console.log('fail')
      }
    })
  },

  addToDB: function (fileID) {
    console.log("begain addtoDB");
    var form = this.data.form;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'db',
      // 传给云函数的参数
      data: {
        type: 'add',
        img: fileID,
        comment: form.comment
      },
      success(res) {
        console.log('upload success!'),
          wx.showToast({
            title: '保存成功'
          })
      },
      fail() {
        console.log('upload fail!')
      }
    })
  },

  S4: function () {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
  },
  guid: function () {
    return (this.S4() + this.S4() + "-" + this.S4() + "-" + this.S4() + "-" + this.S4() + "-" + this.S4() + this.S4() + this.S4());
  },

  onShow:function(){
    getApp().globalData.index = ''
  }
})
